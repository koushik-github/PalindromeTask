create database task ;
use task;
CREATE TABLE palindrome (
 	id int(11) NOT NULL AUTO_INCREMENT, 
 	list varchar(100) NOT NULL,
 	PRIMARY KEY (id)
 );