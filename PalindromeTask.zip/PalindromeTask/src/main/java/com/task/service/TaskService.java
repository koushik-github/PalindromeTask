package com.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.task.dao.TaskDAO;
import com.task.entity.Palindrome;

@Service("taskService")
public class TaskService {

	@Autowired
	TaskDAO taskDAO;
	
	@Transactional
	public List<Palindrome> getAllList() {
		return taskDAO.getAllList();
	}

	@Transactional
	public void addPalindrome(Palindrome palindrome) {
		taskDAO.addPalindrome(palindrome);
	}

	@Transactional
	public Palindrome getListByPalindrome(String palString) {
		return taskDAO.getListByPalindrome(palString);
	}


}
