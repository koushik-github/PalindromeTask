package com.task.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.task.entity.Palindrome;
import com.task.service.TaskService;

@Controller
public class TaskController {
	
	@Autowired
	TaskService taskService;
	
	@RequestMapping(value ={"/","/welcome"}, method = RequestMethod.GET, headers = "Accept=application/json")
	public String home(Model model) throws JsonProcessingException {
		List<Palindrome> lPalme = taskService.getAllList();
		model.addAttribute("palindrome", new Palindrome());
		ObjectMapper mapper = new ObjectMapper();
		model.addAttribute("listPalindrome", mapper.writeValueAsString(lPalme));
		return "palindromePage";
	}
	
	@RequestMapping(value = "/addPalindromeList", method = RequestMethod.POST, headers = "Accept=application/json")
	public String addPalindromeList(@ModelAttribute("palindrome") Palindrome palindrome,RedirectAttributes redirectAttributes ) {	
		
		 String palString = palindrome.getList();
		 int length = palString.length();
		 String reverse = "";
		 for (int i = length - 1; i >= 0; i--) {
			 reverse = reverse + palString.charAt(i);
		 }
	     if( !palString.equalsIgnoreCase(reverse)) {
	    	 redirectAttributes.addFlashAttribute("error", "The text isn't a palindrome.");
	     }else {
	    	 Palindrome palmObj = taskService.getListByPalindrome(palString.toUpperCase());
	    	 if(palmObj == null ) {
	    		 taskService.addPalindrome(palindrome);
	    		 redirectAttributes.addFlashAttribute("success", "Palindrome text added successfully!");
	    	 }else {
	    		 redirectAttributes.addFlashAttribute("error", "The text already exist in db.");
	    	 }
	     }
		return "redirect:/welcome";
	}
}
